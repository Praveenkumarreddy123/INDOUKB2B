			
<?php 
	
	$pagenameObj = $_SERVER['PHP_SELF'];
	$pagename =  explode("/", $pagenameObj);
	$count = count($pagename);
	$pagename  = $pagename[$count-1];
	$footerposiblepages = array("index.php", "about.php", "contact-us.php"); 
?>

</div>
			</section>

		</div>
		<?php 
			if(in_array($pagename , $footerposiblepages)) {

			
		 ?> 
		<footer class="footer">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 padding0">
				<div class="main_block">
					<ul class="list-inline social-icons text-center">
						<li class="list-inline-item"><a href="#" target="_blank" class="fb"></a></li>
						<li class="list-inline-item "><a href="#" target="_blank" class="twitter"></a></li>
						<li class="list-inline-item "><a href="#" target="_blank" class="linkedIn"></a></li>
					</ul>
					<p class="text-white text-center m-0">&copy; 
						<script>  document.write(new Date().getFullYear()); </script>  
						IndoUkB2B.in  All rights reserved.</p>
				</div>
			</div>
		</footer>
		<?php } ?> 
	</body>
	<!-- Scripts -->
	<!--[if IE 8]>
		<script src="assets/js/IE8.js" type="text/javascript"></script>
	<![endif]-->
	<!--[if lt IE 9]>
		<script src="assets/js/respond.min.js"></script>
		<script src="assets/js/html5shiv.js"></script>
	<![endif]-->
	<script src="assets/js/html5.js" type="text/javascript"></script>
	<script src="assets/js/jquery-1.11.1.js" type="text/javascript"></script>
	<script src="assets/js/flowtype.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/function.js" type="text/javascript"></script>
	<!-- Scripts -->
</html>