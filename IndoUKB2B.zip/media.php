<?php include_once("header.php"); ?>
	<div id="primary" class="media_page">
        <div class="media_header">
            <div class="main_block">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">VIDEOS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">NEWS FEEDS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">GALLERY</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact-1" role="tab" aria-controls="pills-contact" aria-selected="false">TESTIMONIALS</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="media_section">
            <div class="main_block">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                        <div class="row">
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap">
                                        <div class="youtube_icon"></div>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">Watch video</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <div class="row">
                            <div class="col-12 col-sm-6 col-md-4 col-lg-4 card_container">
                                <div class="card">
                                    <div class="image_container">
                                        <img class="card-img-top" src="assets/images/B2B.jpg" alt="Card image cap"> 
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title">Why Indians to be united? Launching Video...</h5>
                                        <p class="card-text">The India B2B portal is a platform exclusively made for Indians across the world where business community can interact with each other in terms of buying and selling. The Goal is to support each and every India in their respective entrepreneurial and professional endeavours through networked collaborations.</p>
                                        <div class="FormContainer p-0 m-0 mt-5 box-shadow-none">
                                            <button type="button" class="btn btn-primary site-form-button width-auto inline-small-button step_1_Form w-100">READ MORE</button>
                                        </div> 
                                    </div>
                                </div>
                            </div>   
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <p class="comming_soon text-center">Comming Soon</p>
                    </div>
                    <div class="tab-pane fade testimonials" id="pills-contact-1" role="tabpanel" aria-labelledby="pills-contact-tab">
                        <p class="comming_soon text-center">Comming Soon</p>
                        <div id="carouselExampleControls" class="carousel slide d-none" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="row">
                                        <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                            <div class="testimony_profile_img">
                                                <img src="assets/images/testimonial-profile.png" alt="Testimony-Profile-Img" />
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                                            <p class="testimony_content">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                            Phasellus mauris arcu, gravida nec ante sed, ullamcorper
                                            eleifend velit. Class aptent taciti sociosqu ad litora
                                            torquent per"</p>
                                            <p class="testimony_profile_details">
                                                <span class="name">JOHN PETER</span>
                                                <span class="desigination">EXEC. DIRECTOR, ISKO</span>
                                            </p>
                                        </div>
                                    <div>
                                </div>
                                <div class="carousel-item">
                                    <div class="row">
                                            <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                                <div class="testimony_profile_img">
                                                    <img src="assets/images/testimonial-profile.png" alt="Testimony-Profile-Img" />
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                                                <p class="testimony_content">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                                Phasellus mauris arcu, gravida nec ante sed, ullamcorper
                                                eleifend velit. Class aptent taciti sociosqu ad litora
                                                torquent per"</p>
                                                <p class="testimony_profile_details">
                                                    <span class="name">JOHN PETER</span>
                                                    <span class="desigination">EXEC. DIRECTOR, ISKO</span>
                                                </p>
                                            </div>
                                        <div>
                                    </div>
                                <div class="carousel-item">
                                    <div class="row">
                                            <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3">
                                                <div class="testimony_profile_img">
                                                    <img src="assets/images/testimonial-profile.png" alt="Testimony-Profile-Img" />
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-12 col-md-9 col-lg-9 col-xl-9">
                                                <p class="testimony_content">"Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                                                Phasellus mauris arcu, gravida nec ante sed, ullamcorper
                                                eleifend velit. Class aptent taciti sociosqu ad litora
                                                torquent per"</p>
                                                <p class="testimony_profile_details">
                                                    <span class="name">JOHN PETER</span>
                                                    <span class="desigination">EXEC. DIRECTOR, ISKO</span>
                                                </p>
                                            </div>
                                        <div>
                                    </div>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
<?php include_once("footer.php"); ?>